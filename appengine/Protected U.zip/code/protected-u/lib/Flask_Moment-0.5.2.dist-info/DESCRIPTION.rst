
Flask-Moment
------------

Formatting of dates and times in Flask templates using moment.js.



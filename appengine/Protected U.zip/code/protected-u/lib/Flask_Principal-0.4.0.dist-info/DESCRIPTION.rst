Flask Principal
---------------

Identity management for Flask.

Links
`````

* `documentation <http://packages.python.org/Flask-Principal/>`_
* `source <https://github.com/mattupstate/flask-principal>`_
* `development version
  <https://github.com/mattupstate/flask-principal/raw/master#egg=Flask-Principal-dev>`_



